﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class saless
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txttotal = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.quant = New System.Windows.Forms.TextBox()
        Me.emp = New System.Windows.Forms.TextBox()
        Me.con = New System.Windows.Forms.TextBox()
        Me.addr = New System.Windows.Forms.TextBox()
        Me.surname = New System.Windows.Forms.TextBox()
        Me.nm = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.DateTimePicker3 = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.totalsss = New System.Windows.Forms.TextBox()
        Me.q = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.c = New System.Windows.Forms.TextBox()
        Me.a = New System.Windows.Forms.TextBox()
        Me.s = New System.Windows.Forms.TextBox()
        Me.n = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.FirstName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.addres = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cont = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.prod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.qua = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.n1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.n2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Addrs = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cntct = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Quants = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ResDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RpuDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prdcts = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sze = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ttl = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(0, 0)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "b"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(33, 373)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(142, 36)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "PURCHASE"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(17, 391)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(142, 36)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "RESERVATION"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(252, 437)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(142, 36)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "CANCEL RESERVATION"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(452, 508)
        Me.TabControl1.TabIndex = 5
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.txttotal)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.ComboBox2)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.ComboBox1)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.quant)
        Me.TabPage1.Controls.Add(Me.emp)
        Me.TabPage1.Controls.Add(Me.con)
        Me.TabPage1.Controls.Add(Me.addr)
        Me.TabPage1.Controls.Add(Me.surname)
        Me.TabPage1.Controls.Add(Me.nm)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(444, 482)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Customer"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(267, 373)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(142, 36)
        Me.Button4.TabIndex = 26
        Me.Button4.Text = "LOGOUT"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(18, 307)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 13)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Total:"
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(73, 304)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.Size = New System.Drawing.Size(139, 20)
        Me.txttotal.TabIndex = 24
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(312, 149)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(27, 13)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Size"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"S", "M", "L"})
        Me.ComboBox2.Location = New System.Drawing.Point(300, 165)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(285, 85)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Date Purchase"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(244, 110)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(285, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Select Products"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(279, 44)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(18, 259)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Quantity:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 224)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Employee ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 183)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Contact:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 149)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Address:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 110)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Surname:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Name:"
        '
        'quant
        '
        Me.quant.Location = New System.Drawing.Point(73, 259)
        Me.quant.Name = "quant"
        Me.quant.Size = New System.Drawing.Size(139, 20)
        Me.quant.TabIndex = 10
        '
        'emp
        '
        Me.emp.Location = New System.Drawing.Point(73, 221)
        Me.emp.Name = "emp"
        Me.emp.Size = New System.Drawing.Size(139, 20)
        Me.emp.TabIndex = 9
        '
        'con
        '
        Me.con.Location = New System.Drawing.Point(73, 180)
        Me.con.Name = "con"
        Me.con.Size = New System.Drawing.Size(139, 20)
        Me.con.TabIndex = 8
        '
        'addr
        '
        Me.addr.Location = New System.Drawing.Point(73, 146)
        Me.addr.Name = "addr"
        Me.addr.Size = New System.Drawing.Size(139, 20)
        Me.addr.TabIndex = 7
        '
        'surname
        '
        Me.surname.Location = New System.Drawing.Point(73, 107)
        Me.surname.Name = "surname"
        Me.surname.Size = New System.Drawing.Size(139, 20)
        Me.surname.TabIndex = 6
        '
        'nm
        '
        Me.nm.Location = New System.Drawing.Point(73, 65)
        Me.nm.Name = "nm"
        Me.nm.Size = New System.Drawing.Size(139, 20)
        Me.nm.TabIndex = 5
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label23)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.Label21)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.DateTimePicker3)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.DateTimePicker2)
        Me.TabPage2.Controls.Add(Me.ComboBox4)
        Me.TabPage2.Controls.Add(Me.ComboBox3)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.Label16)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.totalsss)
        Me.TabPage2.Controls.Add(Me.q)
        Me.TabPage2.Controls.Add(Me.TextBox6)
        Me.TabPage2.Controls.Add(Me.c)
        Me.TabPage2.Controls.Add(Me.a)
        Me.TabPage2.Controls.Add(Me.s)
        Me.TabPage2.Controls.Add(Me.n)
        Me.TabPage2.Controls.Add(Me.Button3)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(444, 482)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(231, 25)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(90, 13)
        Me.Label22.TabIndex = 25
        Me.Label22.Text = "Reservation Date" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(322, 189)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(27, 13)
        Me.Label21.TabIndex = 24
        Me.Label21.Text = "Size"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(252, 388)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(142, 39)
        Me.Button5.TabIndex = 23
        Me.Button5.Text = "Confirmation"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'DateTimePicker3
        '
        Me.DateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker3.Location = New System.Drawing.Point(223, 121)
        Me.DateTimePicker3.Name = "DateTimePicker3"
        Me.DateTimePicker3.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker3.TabIndex = 22
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(322, 144)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(49, 13)
        Me.Label20.TabIndex = 21
        Me.Label20.Text = "Products" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker2.Location = New System.Drawing.Point(223, 50)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2.TabIndex = 20
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"S", "M", "L"})
        Me.ComboBox4.Location = New System.Drawing.Point(287, 208)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 19
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(287, 160)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 18
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(15, 302)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 13)
        Me.Label19.TabIndex = 17
        Me.Label19.Text = "Total"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(3, 232)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(70, 13)
        Me.Label18.TabIndex = 16
        Me.Label18.Text = "Employee ID:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(10, 269)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(46, 13)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "Quantity"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(8, 182)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(47, 13)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "Contact:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(7, 144)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(45, 13)
        Me.Label15.TabIndex = 13
        Me.Label15.Text = "Address"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 104)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(52, 13)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "Surname:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(15, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 13)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Name:"
        '
        'totalsss
        '
        Me.totalsss.Location = New System.Drawing.Point(73, 299)
        Me.totalsss.Name = "totalsss"
        Me.totalsss.Size = New System.Drawing.Size(131, 20)
        Me.totalsss.TabIndex = 10
        '
        'q
        '
        Me.q.Location = New System.Drawing.Point(73, 266)
        Me.q.Name = "q"
        Me.q.Size = New System.Drawing.Size(131, 20)
        Me.q.TabIndex = 9
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(73, 229)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(131, 20)
        Me.TextBox6.TabIndex = 8
        '
        'c
        '
        Me.c.Location = New System.Drawing.Point(73, 182)
        Me.c.Name = "c"
        Me.c.Size = New System.Drawing.Size(131, 20)
        Me.c.TabIndex = 7
        '
        'a
        '
        Me.a.Location = New System.Drawing.Point(73, 144)
        Me.a.Name = "a"
        Me.a.Size = New System.Drawing.Size(131, 20)
        Me.a.TabIndex = 6
        '
        's
        '
        Me.s.Location = New System.Drawing.Point(73, 104)
        Me.s.Name = "s"
        Me.s.Size = New System.Drawing.Size(131, 20)
        Me.s.TabIndex = 5
        '
        'n
        '
        Me.n.Location = New System.Drawing.Point(73, 54)
        Me.n.Name = "n"
        Me.n.Size = New System.Drawing.Size(131, 20)
        Me.n.TabIndex = 4
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FirstName, Me.lname, Me.addres, Me.Cont, Me.prod, Me.qua, Me.dp, Me.Total})
        Me.DataGridView1.Location = New System.Drawing.Point(460, 285)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(626, 219)
        Me.DataGridView1.TabIndex = 6
        '
        'FirstName
        '
        Me.FirstName.HeaderText = "Name"
        Me.FirstName.Name = "FirstName"
        '
        'lname
        '
        Me.lname.HeaderText = "Surname"
        Me.lname.Name = "lname"
        '
        'addres
        '
        Me.addres.HeaderText = "Address"
        Me.addres.Name = "addres"
        '
        'Cont
        '
        Me.Cont.HeaderText = "Contact"
        Me.Cont.Name = "Cont"
        '
        'prod
        '
        Me.prod.HeaderText = "Product"
        Me.prod.Name = "prod"
        '
        'qua
        '
        Me.qua.HeaderText = "Quantity"
        Me.qua.Name = "qua"
        '
        'dp
        '
        Me.dp.HeaderText = "Date Purchase"
        Me.dp.Name = "dp"
        '
        'Total
        '
        Me.Total.HeaderText = "Total Purchase"
        Me.Total.Name = "Total"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(736, 265)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(88, 13)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Your Transaction"
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(460, 18)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(626, 227)
        Me.DataGridView2.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(707, 3)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Available Items"
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.n1, Me.n2, Me.Addrs, Me.Cntct, Me.Quants, Me.ResDate, Me.RpuDate, Me.Prdcts, Me.Sze, Me.ttl})
        Me.DataGridView3.Location = New System.Drawing.Point(460, 285)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(626, 223)
        Me.DataGridView3.TabIndex = 10
        '
        'n1
        '
        Me.n1.HeaderText = "Name"
        Me.n1.Name = "n1"
        '
        'n2
        '
        Me.n2.HeaderText = "Surname"
        Me.n2.Name = "n2"
        '
        'Addrs
        '
        Me.Addrs.HeaderText = "Address"
        Me.Addrs.Name = "Addrs"
        '
        'Cntct
        '
        Me.Cntct.HeaderText = "Contact"
        Me.Cntct.Name = "Cntct"
        '
        'Quants
        '
        Me.Quants.HeaderText = "Quantity"
        Me.Quants.Name = "Quants"
        '
        'ResDate
        '
        Me.ResDate.HeaderText = "Reservation Date"
        Me.ResDate.Name = "ResDate"
        '
        'RpuDate
        '
        Me.RpuDate.HeaderText = "Reservation Pick Up Date"
        Me.RpuDate.Name = "RpuDate"
        '
        'Prdcts
        '
        Me.Prdcts.HeaderText = "Products"
        Me.Prdcts.Name = "Prdcts"
        '
        'Sze
        '
        Me.Sze.HeaderText = "Size"
        Me.Sze.Name = "Sze"
        '
        'ttl
        '
        Me.ttl.HeaderText = "total"
        Me.ttl.Name = "ttl"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(231, 88)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(132, 13)
        Me.Label23.TabIndex = 26
        Me.Label23.Text = "Reservation Pick up  Date" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'saless
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1279, 507)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "saless"
        Me.Text = "sales"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents quant As System.Windows.Forms.TextBox
    Friend WithEvents emp As System.Windows.Forms.TextBox
    Friend WithEvents con As System.Windows.Forms.TextBox
    Friend WithEvents addr As System.Windows.Forms.TextBox
    Friend WithEvents surname As System.Windows.Forms.TextBox
    Friend WithEvents nm As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents FirstName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents addres As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cont As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents prod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents qua As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dp As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Total As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txttotal As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents c As System.Windows.Forms.TextBox
    Friend WithEvents a As System.Windows.Forms.TextBox
    Friend WithEvents s As System.Windows.Forms.TextBox
    Friend WithEvents n As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents totalsss As System.Windows.Forms.TextBox
    Friend WithEvents q As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker3 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents n1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents n2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Addrs As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cntct As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Quants As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ResDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RpuDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Prdcts As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sze As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ttl As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
End Class
